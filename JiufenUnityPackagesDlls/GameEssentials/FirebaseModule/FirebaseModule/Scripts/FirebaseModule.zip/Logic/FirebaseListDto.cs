﻿using System.Collections.Generic;

public class FirebaseListDto<T>
{
    public int ChildCount;
    public List<T> List;
}
